require "kunlua"
import "layout.layout"
activity.setTheme(android.R.style.Theme_Material_Light_NoActionBar_TranslucentDecor)
activity.setContentView(loadlayout(layout))
title1.text = appname














