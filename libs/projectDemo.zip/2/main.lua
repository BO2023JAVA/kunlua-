require "kunlua"

import "androidx.appcompat.widget.LinearLayoutCompat"
import "com.google.android.material.card.MaterialCardView"
import "androidx.appcompat.widget.ContentFrameLayout"
import "androidx.fragment.app.FragmentContainerView"
import "com.google.android.material.bottomnavigation.BottomNavigationView"
import "com.google.android.material.textview.MaterialTextView"
import "com.androlua.LuaFragment"
import "com.google.android.material.bottomnavigation.LabelVisibilityMode"

-- 加载布局文件
import "layout.layout"
-- 设置主布局
activity.setContentView(loadlayout(layout))
title1.text = appname

local MDC_R = luajava.bindClass "com.google.android.material.R"

-- 创建Fragment内容的函数
local function getFragmentView(param)
  return loadlayout({
    LinearLayoutCompat;
    orientation="vertical";
    layout_width="match";
    layout_height="match";
    gravity="center";
    {
      MaterialTextView;
      text=param.." 内容";
      textColor=0xFF000000; -- 黑色
      textStyle="bold";
      textSize="28sp";
    };
  })
end

-- 获取Fragment管理器
local fragmentManager = activity.getSupportFragmentManager()

-- 准备Fragment和对应的View
local Fragments = {}
local Views = {
  getFragmentView("搜索"),
  getFragmentView("编辑"),
  getFragmentView("语音")
}

-- 正确创建LuaFragment
for k, view in ipairs(Views) do
  Fragments[k] = LuaFragment(view) -- 直接传入View构造
end

-- 初始显示第一个Fragment
fragmentManager.beginTransaction()
.add(FragmentContainer.getId(), Fragments[1])
.commit()

-- 底部导航菜单配置
local menu = {
  { title = "搜索", icon = MDC_R.drawable.abc_ic_search_api_material },
  { title = "编辑", icon = MDC_R.drawable.material_ic_edit_black_24dp },
  { title = "语音", icon = MDC_R.drawable.abc_ic_voice_search_api_material }
}

-- 添加菜单项
for k, v in ipairs(menu) do
  bottombar.Menu
  .add(0, k-1, k-1, v.title)
  .setIcon(v.icon)
end

-- 设置底部导航点击监听
bottombar.setOnNavigationItemSelectedListener{
  onNavigationItemSelected = function(item)
    fragmentManager.beginTransaction()
    .setCustomAnimations(
    MDC_R.anim.mtrl_bottom_sheet_slide_in,
    MDC_R.anim.mtrl_bottom_sheet_slide_out
    )
    .replace(FragmentContainer.getId(), Fragments[item.getItemId()+1])
    .commit()
    return true
  end
}